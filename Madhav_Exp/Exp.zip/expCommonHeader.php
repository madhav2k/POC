 <table width="100%" border = 0>
  <tr>
    <td width="15%"></td>
    <td width="70%" align = center><img src="expCanvas.php?textType='legend'"> </td>
    <td width="15%">
      <table width="100%" border =0>
      <tr>
        <td><a href="expCommonHeader.php">[Home]</a></td>
        <td><a href="expLogin.php">[Login]</a></td>
        <td><a href="expProfile.php">[Profile]</a></td>
      </tr>
      </table>
    </td>
  </tr>
  <tr>
    <table width="100%" border = 0>
    <tr>
      <td align = center>
        <img src="/images/Cons.gif" height=35>
        <br>
        <a id="cons" href="expConsolidate.php">[Consolidate]</a>
      </td>

      <td align = center>
        <img src="/images/Cons.gif" height=35>
        <br>
        <a id="acqr" href="OfxInfo.php">[Acquire]</a>
      </td>
	  
      <td align = center >
        <img src="/images/Cate.gif" height=35>
        <br>
        <a id="categ" href="expListing.php">[Categorize]</a>
      </td>

      <td align = center>
        <img src="/images/iLLus.gif" height=35>
        <br>
        <a id="illus" href="expContainer.php">[Illustrate]</a>
      </td>

      <td align = center>
        <img src="/images/Publ.gif" height=35>
        <br>
        <a id="publ" href="expPublisher.php">[Publish]</a>
      </td>
    </tr>
    </table>
  </tr>

  </table>

