create database analysis;

GRANT ALL ON analysis.* to data_admin identified by 'data_admin';

