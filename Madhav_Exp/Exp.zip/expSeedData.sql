insert into users(user_Id, user_name, user_password)
values( 1, 'data_admin', 'data_admin');

insert into exp_categories(cat_id, cat_code, cat_meaning)
values(1,'FOOD','Groceries');

insert into exp_categories(cat_id, cat_code, cat_meaning)
values(2,'FUEL','Gasoline');

insert into exp_categories(cat_id, cat_code, cat_meaning)
values(3,'MOVI','Entertainment');

insert into exp_categories(cat_id, cat_code, cat_meaning)
values(4,'IMMI','Immigration');

insert into exp_categories(cat_id, cat_code, cat_meaning)
values(5,'GOLF','Golf');

insert into exp_categories(cat_id, cat_code, cat_meaning)
values(7,'MEDI','Medical');

insert into exp_categories(cat_id, cat_code, cat_meaning)
values(8,'TRVL','Travel');

insert into exp_categories(cat_id, cat_code, cat_meaning)
values(9,'UNKN','Unknown');

insert into exp_categories(cat_id, cat_code, cat_meaning)
values(10,'MISC','Mmiscellaneous');

insert into user_exp_categories(user_id, cat_id)
values(1, 1);

insert into user_exp_categories(user_id, cat_id)
values(1, 2);

insert into user_exp_categories(user_id, cat_id)
values(1, 3);

insert into user_exp_categories(user_id, cat_id)
values(1, 4);

insert into user_exp_categories(user_id, cat_id)
values(1, 5);

insert into user_exp_categories(user_id, cat_id)
values(1, 6);

insert into user_exp_categories(user_id, cat_id)
values(1, 7);

insert into user_exp_categories(user_id, cat_id)
values(1, 8);

insert into user_exp_categories(user_id, cat_id)
values(1, 9);


insert into user_exp_categories(user_id, cat_id)
values(1, 10);









