<div style="padding: 10px;">
	<p>The Results of your form submission are as follows:</p>
	<p>Your Name: <span style="font-weight: bold;"><?=$_POST['yourname']?></span></p>
	<p>Your Name: <span style="font-weight: bold;"><?=$_POST['youremail']?></span></p>
	<p>Comments: <span style="font-weight: bold;"><?=$_POST['comment']?></span></p>
</div>